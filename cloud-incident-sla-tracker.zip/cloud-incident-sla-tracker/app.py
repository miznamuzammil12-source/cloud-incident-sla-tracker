import streamlit as st
import pandas as pd
import plotly.express as px
from datetime import datetime

st.set_page_config(
    page_title="Cloud Incident SLA Tracker",
    page_icon="🎫",
    layout="wide"
)

st.title("🎫 Cloud Support Incident Management and SLA Tracking System")
st.write(
    "Advanced cloud support dashboard for tracking incidents, priorities, SLA deadlines, escalations, "
    "root causes, resolution status, and support performance."
)

@st.cache_data
def load_data():
    return pd.read_csv("data/cloud_incidents.csv")

df = load_data()

df["created_at"] = pd.to_datetime(df["created_at"])
df["sla_due_at"] = pd.to_datetime(df["sla_due_at"])
df["resolved_at"] = pd.to_datetime(df["resolved_at"], errors="coerce")

current_time = pd.Timestamp.now()

def sla_status(row):
    if pd.notna(row["resolved_at"]):
        if row["resolved_at"] <= row["sla_due_at"]:
            return "Met"
        return "Breached"

    hours_left = (row["sla_due_at"] - current_time).total_seconds() / 3600

    if hours_left < 0:
        return "Breached"
    if hours_left <= 4:
        return "At Risk"
    return "On Track"

def age_hours(row):
    end_time = row["resolved_at"] if pd.notna(row["resolved_at"]) else current_time
    return round((end_time - row["created_at"]).total_seconds() / 3600, 2)

def priority_score(priority):
    return {"Low": 1, "Medium": 2, "High": 3, "Critical": 4}.get(priority, 1)

df["sla_status"] = df.apply(sla_status, axis=1)
df["age_hours"] = df.apply(age_hours, axis=1)
df["priority_score"] = df["priority"].apply(priority_score)

st.sidebar.header("Filters")
status_filter = st.sidebar.multiselect("Ticket Status", sorted(df["status"].unique()), default=sorted(df["status"].unique()))
priority_filter = st.sidebar.multiselect("Priority", sorted(df["priority"].unique()), default=sorted(df["priority"].unique()))
team_filter = st.sidebar.multiselect("Assigned Team", sorted(df["assigned_team"].unique()), default=sorted(df["assigned_team"].unique()))
sla_filter = st.sidebar.multiselect("SLA Status", sorted(df["sla_status"].unique()), default=sorted(df["sla_status"].unique()))

filtered = df[
    (df["status"].isin(status_filter)) &
    (df["priority"].isin(priority_filter)) &
    (df["assigned_team"].isin(team_filter)) &
    (df["sla_status"].isin(sla_filter))
].copy()

total_tickets = len(filtered)
open_tickets = len(filtered[filtered["status"].isin(["Open", "In Progress", "Escalated", "Pending Customer"])])
critical_tickets = len(filtered[filtered["priority"] == "Critical"])
sla_breached = len(filtered[filtered["sla_status"] == "Breached"])
at_risk = len(filtered[filtered["sla_status"] == "At Risk"])
avg_resolution = filtered[filtered["status"] == "Resolved"]["age_hours"].mean()

col1, col2, col3, col4, col5, col6 = st.columns(6)
col1.metric("Total Tickets", total_tickets)
col2.metric("Active Tickets", open_tickets)
col3.metric("Critical", critical_tickets)
col4.metric("SLA Breached", sla_breached)
col5.metric("SLA At Risk", at_risk)
col6.metric("Avg Resolution", f"{avg_resolution:.1f} hrs" if pd.notna(avg_resolution) else "N/A")

st.divider()

left, right = st.columns(2)

with left:
    st.subheader("Tickets by Priority")
    fig = px.histogram(filtered, x="priority", color="status", barmode="group")
    st.plotly_chart(fig, use_container_width=True)

with right:
    st.subheader("SLA Performance")
    sla_df = filtered["sla_status"].value_counts().reset_index()
    sla_df.columns = ["sla_status", "count"]
    fig = px.pie(sla_df, names="sla_status", values="count", title="SLA Status Distribution")
    st.plotly_chart(fig, use_container_width=True)

left2, right2 = st.columns(2)

with left2:
    st.subheader("Incident Categories")
    cat_df = filtered["category"].value_counts().reset_index()
    cat_df.columns = ["category", "count"]
    fig = px.bar(cat_df, x="category", y="count", title="Incident Volume by Category")
    st.plotly_chart(fig, use_container_width=True)

with right2:
    st.subheader("Team Workload")
    team_df = filtered["assigned_team"].value_counts().reset_index()
    team_df.columns = ["assigned_team", "ticket_count"]
    fig = px.bar(team_df, x="assigned_team", y="ticket_count", title="Assigned Tickets by Team")
    st.plotly_chart(fig, use_container_width=True)

st.subheader("SLA Breach and Escalation Queue")
escalation_queue = filtered[
    (filtered["sla_status"].isin(["Breached", "At Risk"])) |
    (filtered["priority"].isin(["Critical", "High"])) |
    (filtered["status"] == "Escalated")
].sort_values(["priority_score", "age_hours"], ascending=[False, False])

st.dataframe(
    escalation_queue[
        [
            "ticket_id", "created_at", "sla_due_at", "title", "category", "priority", "status",
            "assigned_team", "customer", "impact", "age_hours", "sla_status", "root_cause"
        ]
    ],
    use_container_width=True
)

st.subheader("Automated Support Recommendations")
if not escalation_queue.empty:
    for _, row in escalation_queue.head(10).iterrows():
        action = "Escalate immediately" if row["sla_status"] == "Breached" or row["priority"] == "Critical" else "Review and update customer"
        st.warning(
            f"{action}: {row['ticket_id']} - {row['title']} | Priority: {row['priority']} | "
            f"SLA: {row['sla_status']} | Team: {row['assigned_team']}."
        )
else:
    st.success("No urgent tickets in the current filter selection.")

st.subheader("Root Cause Analysis")
rc_df = filtered["root_cause"].value_counts().reset_index()
rc_df.columns = ["root_cause", "count"]
fig = px.bar(rc_df, x="root_cause", y="count", title="Most Common Root Causes")
st.plotly_chart(fig, use_container_width=True)

st.subheader("Full Incident Register")
st.dataframe(filtered.sort_values(["priority_score", "created_at"], ascending=[False, True]), use_container_width=True)

report = filtered.sort_values(["priority_score", "created_at"], ascending=[False, True]).to_csv(index=False).encode("utf-8")
st.download_button(
    "Download SLA Incident Report",
    report,
    file_name="cloud_incident_sla_report.csv",
    mime="text/csv"
)