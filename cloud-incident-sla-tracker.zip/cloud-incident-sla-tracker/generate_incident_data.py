import pandas as pd
import random
from datetime import datetime, timedelta

random.seed(88)
categories = ["Cloud", "Network", "Security", "Application", "Database", "Storage", "Authentication"]
priorities = ["Low", "Medium", "High", "Critical"]
statuses = ["Open", "In Progress", "Resolved", "Escalated", "Pending Customer"]
teams = ["CloudOps", "Security", "Application Support", "Database Team", "Network Team"]
customers = ["Hospital Group A", "Clinic Network B", "Healthcare Client C", "Internal Team", "Enterprise Client D"]
titles = [
    "VM unreachable", "High CPU usage", "Failed login spike", "API timeout", "Database connection issue",
    "Storage usage exceeded", "Firewall rule misconfiguration", "SSL certificate warning", "Backup job failed",
    "Application service down", "Network latency increased", "User authentication failure"
]

rows = []
now = datetime.now()

for i in range(220):
    priority = random.choices(priorities, weights=[35, 35, 20, 10])[0]
    status = random.choices(statuses, weights=[25, 25, 30, 10, 10])[0]
    created = now - timedelta(hours=random.randint(1, 360))
    sla_hours = {"Low": 72, "Medium": 48, "High": 24, "Critical": 8}[priority]
    due = created + timedelta(hours=sla_hours)

    if status == "Resolved":
        resolved = created + timedelta(hours=random.randint(1, max(2, sla_hours + 20)))
    else:
        resolved = None

    rows.append({
        "ticket_id": f"INC-{1000+i}",
        "created_at": created.strftime("%Y-%m-%d %H:%M:%S"),
        "sla_due_at": due.strftime("%Y-%m-%d %H:%M:%S"),
        "resolved_at": resolved.strftime("%Y-%m-%d %H:%M:%S") if resolved else "",
        "title": random.choice(titles),
        "category": random.choice(categories),
        "priority": priority,
        "status": status,
        "assigned_team": random.choice(teams),
        "customer": random.choice(customers),
        "impact": random.choice(["Single user", "Multiple users", "Department", "Production system", "Business critical"]),
        "root_cause": random.choice(["Configuration issue", "Resource exhaustion", "Network issue", "Access issue", "Unknown", "Application error"]),
        "resolution_notes": random.choice([
            "Restarted affected service and monitored stability.",
            "Escalated to cloud operations for investigation.",
            "Updated configuration and verified service recovery.",
            "Increased resource limits and reviewed monitoring alerts.",
            "Pending customer confirmation.",
            "Security review completed and access logs verified."
        ])
    })

pd.DataFrame(rows).to_csv("data/cloud_incidents.csv", index=False)
print("Generated data/cloud_incidents.csv")