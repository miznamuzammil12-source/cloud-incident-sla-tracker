# Cloud Support Incident Management and SLA Tracking System

## Overview

Cloud Support Incident Management and SLA Tracking System is an advanced support operations project designed for cloud support, application support, and CloudOps teams. It helps teams track cloud incidents, monitor SLA deadlines, identify breached tickets, manage escalations, analyze root causes, and generate support reports.

This project simulates a professional incident management workflow similar to cloud support environments where teams must handle production issues, customer tickets, service outages, security incidents, and SLA-based support responsibilities.

## Features

- Cloud incident ticket tracking
- SLA deadline monitoring
- SLA status classification: On Track, At Risk, Breached, Met
- Priority levels: Low, Medium, High, Critical
- Ticket status tracking
- Escalation queue
- Automated support recommendations
- Team workload analytics
- Incident category analysis
- Root cause analysis
- Average resolution time calculation
- Customer impact tracking
- Downloadable SLA incident report
- Interactive filters by status, priority, team, and SLA status

## Tech Stack

- Python
- Streamlit
- Pandas
- Plotly
- Mock cloud support incident dataset

## Dataset

The dataset contains simulated cloud support incident tickets with:

- Ticket ID
- Created date and time
- SLA due date and time
- Resolved date and time
- Incident title
- Category
- Priority
- Status
- Assigned team
- Customer
- Impact
- Root cause
- Resolution notes

## How It Works

1. Loads cloud incident ticket data.
2. Calculates ticket age and SLA status.
3. Detects tickets that are breached, at risk, critical, or escalated.
4. Displays key support metrics such as active tickets, critical tickets, SLA breaches, and average resolution time.
5. Shows dashboards for ticket priority, SLA performance, incident categories, team workload, and root causes.
6. Creates an escalation queue for urgent tickets.
7. Generates automated support recommendations.
8. Allows users to download the full SLA incident report.

## Project Structure

```text
cloud-incident-sla-tracker/
│
├── app.py
├── generate_incident_data.py
├── requirements.txt
├── README.md
│
├── data/
│   └── cloud_incidents.csv
│
├── reports/
│   └── sample_sla_incident_report.csv
│
├── screenshots/
│
├── portfolio_description.txt
└── cv_description.txt
```

## Installation

```bash
pip install -r requirements.txt
```

## Run the Application

```bash
streamlit run app.py
```

## Use Case

This dashboard is useful for cloud support and application support teams that need to manage tickets, monitor SLAs, handle escalations, track root causes, and improve service reliability.

## CV Description

Created a cloud support incident management and SLA tracking system using Python, Streamlit, Pandas, and Plotly to monitor ticket priorities, SLA deadlines, escalations, root causes, team workload, and resolution performance with downloadable support reports.

## Skills Demonstrated

- Cloud support operations
- Incident management
- SLA monitoring
- Escalation handling
- Root cause analysis
- Support analytics
- Dashboard development
- Troubleshooting workflow design
- Customer support reporting